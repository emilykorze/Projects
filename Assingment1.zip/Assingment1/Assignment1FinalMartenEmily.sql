/*************************
* IST 359 Assignment 1   *
* Prof. Ferger           *
*************************/

-- Marten Sakharny & Emily Korzendorfer -->> 


-----------------------------
--1.1 
if exists(select * from sys.objects where name='a1_categories') drop table a1_categories;
if exists(select * from sys.objects where name='a1_diners') drop table a1_diners;
if exists(select * from sys.objects where name='a1_restaurants') drop table a1_restaurants;
if exists(select * from sys.objects where name='a1_reviews') drop table a1_reviews;
-----------------------------




GO

-----------------------------
-- 1.2
CREATE TABLE a1_reviews (
reviews_id int identity(1,1) not null,
reviews_stars int not null,
reviews_date datetime not null,
reviews_complete bit default(0) not null,
reviews_restaurant_id int null,
reviews_diner_id int null
)
-----------------------------


GO

-----------------------------
-- 1.3
CREATE TABLE a1_restaurants (
restaurant_id int identity(1,1) not null,
restaurant_name varchar(50) not null,
restaurant_hours varchar(50) not null,
restaurant_phone varchar(15)not null,
restaurant_number_locations int default(1) not null, 
restaurant_record_created datetime default(GETDATE()) not null,
restaurant_category_id int null
)
-----------------------------



GO

-----------------------------
-- 1.4
CREATE TABLE a1_diners (
diners_id int identity (1,1) not null,
diners_firstname varchar(30) not null,
diners_lastname varchar(30) not null,
diners_email varchar(254) not null
)
-----------------------------



GO


-----------------------------
-- 1.5
CREATE TABLE a1_categories (
categories_id int identity (1,1) not null,
categories_type varchar(30) not null
)
-----------------------------



GO

-----------------------------
-- 2.1
alter table a1_reviews
add
constraint pk_reviews_id primary key (reviews_id),
constraint ck_reviews_date Check (reviews_date<GETDATE()),
constraint ck_stars Check (reviews_stars between 1 and 4)

-----------------------------


GO

-----------------------------
-- 2.2
alter table a1_restaurants
add
constraint pk_restaurant_id primary key (restaurant_id),
constraint ck_no_locations check (restaurant_number_locations>0)
-----------------------------


GO

-----------------------------
-- 2.3
alter table a1_diners
add
constraint pk_diner_id primary key(diners_id)
-----------------------------


GO

-----------------------------
-- 2.4
alter table a1_categories
add
constraint pk_categories_id primary key (categories_id)
-----------------------------


GO

-----------------------------
-- 3.1
alter table a1_reviews
		add constraint fk_reviews_restaurant_id 
		foreign key (reviews_restaurant_id)	references a1_restaurants(restaurant_id),

		constraint fk_reviews_diner_id
		foreign key (reviews_diner_id)	references a1_diners(diners_id)
-----------------------------



GO

-----------------------------
-- 3.2
alter table a1_restaurants
		add constraint fk_category_id
		foreign key (restaurant_category_id) references a1_categories(categories_id)
-----------------------------



GO

-----------------------------
-- 5.1
INSERT INTO a1_restaurants (
restaurant_name,
restaurant_hours,
restaurant_phone,
restaurant_number_locations,
restaurant_record_created
) VALUES (
'Dinosaur BBQ',
'11am-11pm',
'(315) 476-4937)',
'10',
'4/1/15'
)

INSERT INTO a1_restaurants (
restaurant_name,
restaurant_hours,
restaurant_phone,
restaurant_number_locations,
restaurant_record_created
) VALUES (
'Alto Cinco',
'8am-12am',
'(315) 422-6399)',
'2',
'5/1/18'
)

INSERT INTO a1_restaurants (
restaurant_name,
restaurant_hours,
restaurant_phone,
restaurant_number_locations,
restaurant_record_created
) VALUES (
'Funk ''n Waffles',
'9am-4pm',
'(315) 477-9700)',
'1',
'6/1/15'
)

-----------------------------


		
GO

-----------------------------
-- 5.2
INSERT INTO a1_categories(
categories_type
) VALUES (
'Dine in'
)

INSERT INTO a1_categories(
categories_type
) VALUES (
'Take out'
)

INSERT INTO a1_categories(
categories_type
) VALUES (
'Fast food'
)

INSERT INTO a1_categories(
categories_type
) VALUES (
'Dive'
)
-----------------------------


GO

-----------------------------
-- 5.3
INSERT INTO a1_diners (
diners_firstname,
diners_lastname,
diners_email
) VALUES (
'Rose',
'Olson',
'rolsen@gmail.com'
)


INSERT INTO a1_diners (
diners_firstname,
diners_lastname,
diners_email
) VALUES (
'Pauline',
'Mendoza',
'pmendoza@yahoo.com'
)

-----------------------------	
	


GO

-----------------------------
-- 5.4
INSERT INTO a1_reviews (
reviews_stars,
reviews_date,
reviews_complete,
reviews_restaurant_id,
reviews_diner_id
) VALUES (
4,
'4/2/15',
1,
1,
1
)   

INSERT INTO a1_reviews (
reviews_stars,
reviews_date,
reviews_complete,
reviews_restaurant_id,
reviews_diner_id
) VALUES (
3,
'3/4/15',
1,
2,
2
)

INSERT INTO a1_reviews (
reviews_stars,
reviews_date,
reviews_complete,
reviews_restaurant_id,
reviews_diner_id
) VALUES (
2,
'5/20/15',
0,
2,
2
)

-----------------------------	
	


GO

-----------------------------
-- 6.1
select restaurant_name, reviews_stars, reviews_date, diners_firstname, diners_lastname
from a1_reviews
full join a1_restaurants on restaurant_id = reviews_restaurant_id 
full join a1_diners on reviews_diner_id = diners_id
order by restaurant_name
-----------------------------



GO

-----------------------------
-- 6.2
select
count (reviews_complete) as number_of_incomplete_reviews
from a1_reviews
group by reviews_complete having reviews_complete=0

-----------------------------
GO


			

